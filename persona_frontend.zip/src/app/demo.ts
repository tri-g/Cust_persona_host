export class Demographics{
CLIENT_ID: string; 
SEX:string;
DOB:string;
AGE:number;
FIRST:string;
LAST:string;
PHONE:string;
EMAIL:string;
ADDRESS_1:string;
CITY:string;
}